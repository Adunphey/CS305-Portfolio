package com.artemis.security;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Base64;

public final class CryptoUtil {
    private static final int AES_KEY_BITS = 256;   // JDK 11+ ships with unlimited strength; fine in JDK 24
    private static final int GCM_TAG_BITS = 128;   // 128-bit auth tag
    private static final int GCM_IV_BYTES = 12;    // NIST-recommended IV size for GCM
    private static final SecureRandom RNG = new SecureRandom();

    private CryptoUtil() {}

    public static SecretKey generateKey() throws Exception {
        KeyGenerator kg = KeyGenerator.getInstance("AES");
        kg.init(AES_KEY_BITS);
        return kg.generateKey();
    }

    public static String encrypt(String plaintext, SecretKey key) throws Exception {
        byte[] iv = new byte[GCM_IV_BYTES];
        RNG.nextBytes(iv);

        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(GCM_TAG_BITS, iv));
        byte[] ct = cipher.doFinal(plaintext.getBytes(StandardCharsets.UTF_8));

        // pack iv + ciphertext
        ByteBuffer bb = ByteBuffer.allocate(iv.length + ct.length);
        bb.put(iv).put(ct);
        return Base64.getEncoder().encodeToString(bb.array());
    }

    public static String decrypt(String token, SecretKey key) throws Exception {
        byte[] blob = Base64.getDecoder().decode(token);
        byte[] iv = new byte[GCM_IV_BYTES];
        byte[] ct = new byte[blob.length - GCM_IV_BYTES];
        System.arraycopy(blob, 0, iv, 0, iv.length);
        System.arraycopy(blob, iv.length, ct, 0, ct.length);

        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(GCM_TAG_BITS, iv));
        byte[] pt = cipher.doFinal(ct);
        return new String(pt, StandardCharsets.UTF_8);
    }
}

