package com.artemis.security;

import javax.crypto.SecretKey;

public class DeployCipherDemo {
    public static void main(String[] args) throws Exception {
        // 1) Key (for assignments, generate in-memory; in prod, load from a secure store)
        SecretKey key = CryptoUtil.generateKey();

        // 2) Encrypt some sample data
        String message = "Artemis test payload";
        String token = CryptoUtil.encrypt(message, key);

        // 3) Compute checksum over the encrypted token
        String checksum1 = ChecksumUtil.sha256Hex(token);

        // 4) Recompute to "verify" (should match checksum1)
        String checksum2 = ChecksumUtil.sha256Hex(token);

        // 5) Decrypt and confirm round-trip
        String decrypted = CryptoUtil.decrypt(token, key);
        boolean roundTripOk = message.equals(decrypted);
        boolean checksumOk = checksum1.equals(checksum2);

        System.out.println("Encrypted token (Base64): " + token);
        System.out.println("SHA-256 checksum #1:      " + checksum1);
        System.out.println("SHA-256 checksum #2:      " + checksum2);
        System.out.println("Checksum match?           " + checksumOk);
        System.out.println("Decrypted equals input?   " + roundTripOk);
    }
}
