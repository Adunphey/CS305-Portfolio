package com.artemis.security;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

public final class ChecksumUtil {
    private ChecksumUtil() {}

    public static String sha256Hex(String data) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] digest = md.digest(data.getBytes(StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder(digest.length * 2);
        for (byte b : digest) sb.append(String.format("%02x", b));
        return sb.toString();
    }
}
