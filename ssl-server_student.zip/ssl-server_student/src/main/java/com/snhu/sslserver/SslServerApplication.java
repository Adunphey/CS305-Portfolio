package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Map;

@SpringBootApplication
public class SslServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }

    // ✔️ FIXED: simple route that returns the SHA-256 of static data
    @RestController
    static class ChecksumController {

        @GetMapping("/checksum")
        public Map<String, String> checksum() throws Exception {
            String data = "Hello World Check Sum!"; // static example from the comment
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(data.getBytes(StandardCharsets.UTF_8));

            StringBuilder hex = new StringBuilder(digest.length * 2);
            for (byte b : digest) hex.append(String.format("%02x", b));

            return Map.of(
                "data", data,
                "sha256", hex.toString()
            );
        }
    }
}
